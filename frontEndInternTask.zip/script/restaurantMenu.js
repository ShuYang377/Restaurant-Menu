window.onload = () => {
    new Vue({
        el: "#app-restaurant-menu",
        data: {
            v_message: "Hello World!",
  
            currentSectionNo: 0,
            newSectionFlag: false,
            newItemFlag: false,
  
            sections: [
                {
                    name: "Lunch Special",
                    items: [
                        {
                            title: "Chicken Rice",
                            price: 12
                        }
                    ]
                }, {
                    name: "Dinner Special",
                    items: [
                        {
                            title: "Chicken Noodle",
                            price: 12
                        }, {
                            title: "Green tea",
                            price: 5
                        }
                    ]
                }
            ],
  
            sectionForm: {
                name: ""
            },
  
            itemForm: {
                title: "",
                price: 0
            },
  
            selectSection(index) {
                this.currentSectionNo = index;
                console.log(this.currentSectionNo);
            },
  
            createSection() {
                if (!this.newItemFlag && !this.newSectionFlag) {
                    this.newSectionFlag = true;
                }
            },
  
            confirmNewSection() {
              this.sections.push({
                  name: this.sectionForm.name,
                  items: []
              });
  
              this.newSectionFlag = false;
            },
  
            createItem() {
                if (!this.newItemFlag && !this.newSectionFlag) {
                    if (this.sections.length > 0) {
                        this.newItemFlag = true;
                    }
                }
            },
  
            confirmNewItem() {
                this.sections[this.currentSectionNo].items.push({
                    title: this.itemForm.title,
                    price: this.itemForm.price
                });
  
                this.newItemFlag = false;
            },
  
            cancelNewObject() {
                this.newSectionFlag = false;
                this.newItemFlag = false;
            }
        }
    });
  };